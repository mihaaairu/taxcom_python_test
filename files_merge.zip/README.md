## Build and run the postgres container

```shell
docker-compose up --build
```


> Table setup is stored in [create_table.sql](create_table.sql) (executes automatically with docker container startup).

